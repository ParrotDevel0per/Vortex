import sys
import xbmcgui
import xbmcplugin
import requests
import xbmcaddon
from routing import Plugin

plugin = Plugin()
_ADDON = xbmcaddon.Addon()
_URL = f"plugin://{_ADDON.getAddonInfo('id')}"

informed = _ADDON.getSetting("informed")

if informed != "true":
    _ADDON.setSetting("informed", "true")
    xbmcgui.Dialog().ok("Notification", "Open the addon settings to change server url")
    _ADDON.openSettings()



_SERVER = _ADDON.getSetting('server')
if not _SERVER: xbmcgui.Dialog().ok("Error", "Please set your server in the addon settings"); _ADDON.openSettings(); exit()
if not _SERVER.startswith("http"): xbmcgui.Dialog().ok("Error", "Server URL must start with http:// or https://"); _ADDON.openSettings(); exit()

def addItemToScreen(name, icon, url, isFolder):
    list_item = xbmcgui.ListItem(label=name)
    list_item.setInfo('video', {'title': name,
                                'genre': "",
                                'plot': name,
                                'mediatype': 'video'})
    list_item.setArt({'thumb': icon, 'icon': icon, 'fanart': icon})
    list_item.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(plugin.handle, url, list_item, isFolder)

def addMovie(name, year, poster, imdbID):
    if year: name = f"[{year}] {name}"
    list_item = xbmcgui.ListItem(label=name)
    list_item.setInfo('video', {
                                'title': name,
                                'plot': '',
                                'mediatype': 'video',
                                'year': year
                                })
    #list_item.setArt({'thumb': poster, 'icon': poster, 'fanart': poster})
    list_item.setArt({'poster': poster})
    list_item.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(plugin.handle, f"{_URL}/play/{imdbID}/None/None", list_item, False)

def addShow(name, year, poster, imdbID, season, episode):
    if year: name = f"[{year}] {name}"
    list_item = xbmcgui.ListItem(label=name)
    list_item.setInfo('video', {
                                'title': name,
                                'plot': '',
                                'mediatype': 'video',
                                'year': year
                                })
    #list_item.setArt({'thumb': poster, 'icon': poster, 'fanart': poster})
    list_item.setArt({'poster': poster})
    list_item.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(plugin.handle, f"{_URL}/play/{imdbID}/{season}/{episode}", list_item, False)

@plugin.route('/')
def root():
    xbmcplugin.setContent(plugin.handle, 'Home')
    xbmcplugin.setPluginCategory(plugin.handle, "Home")
    addItemToScreen('Search', '', f"{_URL}/Search", True)
    addItemToScreen('Favorites', '', f"{_URL}/Favorites", True)
    addItemToScreen('Playlist', '', f"{_URL}/Playlist", True)
    addItemToScreen('IMDB Top 250 Movies', '', f"{_URL}/Top250", True)
    addItemToScreen('IMDB Bottom 100 Movies', '', f"{_URL}/Bottom100", True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/Search')
def search():
    xbmcplugin.setContent(plugin.handle, 'Movies')
    xbmcplugin.setPluginCategory(plugin.handle, "Movies")
    query = xbmcgui.Dialog().input('Search', type=xbmcgui.INPUT_ALPHANUM)
    if query:
        results = requests.get(f"{_SERVER}/api/search/scoob").json()["results"]
        for key in results:
            title = results[key]['title']
            try: year = results[key]['year']
            except: year = "IDK"
            try: poster = results[key]['full-size cover url']
            except: poster = f"{_SERVER}/api/poster/{key}?do=show"
            kind = results[key]['kind']
            if kind == "tv series":
                addItemToScreen(f"[{year}] {title}", poster, f"{_URL}/seasons/{key}", True)
            else:
                addMovie(title, year, poster, key)
    else:
        xbmcgui.Dialog().ok('Error', 'No query provided')
        exit()
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/seasons/<id>')
def seasons(id):
    results = requests.get(f"{_SERVER}/api/seasons/{id}").json()["results"]
    title = results["title"]
    poster = results["poster"]
    seasons = int(results["seasons"])
    for i in range(1, seasons+1):
        addItemToScreen(f"Season {i}", poster, f"{_URL}/episodes/{id}/{i}", True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/episodes/<id>/<season>')
def episodes(id, season):
    results = requests.get(f"{_SERVER}/api/episodes/{id}/{season}").json()
    id = results["id"]
    results = results["results"]
    try: poster = results["poster"]
    except: poster = f"{_SERVER}/api/poster/{id}?do=show"
    for result in results:
        if result == "title" or result == "poster": continue
        position = list(results).index(result) - 1
        try: title = f"[{position}] {results[result]['title']}"
        except: title = f"[{position}] IDK"
        addShow(title, "", poster, id, season, position)
    xbmcplugin.endOfDirectory(plugin.handle)
        
@plugin.route('/Favorites')
def favorites():
    results = requests.get(f"{_SERVER}/api/favorites").json()
    if len(results) == 0: xbmcgui.Dialog().ok('Error', 'No favorites found'); exit()
    for result in results:
        title = results[result]['title']
        year = results[result]['year']
        poster = results[result]['poster']
        kind = results[result]['kind']
        if kind == "tv series":
            addItemToScreen(f"[{year}] {title}", poster, f"{_URL}/seasons/{result}", True)
        else:
            addMovie(title, year, poster, result)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/Playlist')
def playlist():
    results = requests.get(f"{_SERVER}/api/playlist").json()
    if len(results) == 0: xbmcgui.Dialog().ok('Error', 'No playlist found'); exit()
    for result in results:
        title = results[result]['title']
        year = results[result]['year']
        poster = results[result]['poster']
        addMovie(title, year, poster, result)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/Top250')
def top250():
    results = requests.get(f"{_SERVER}/api/top250movies/").json()["results"]
    if len(results) == 0: xbmcgui.Dialog().ok('Error', 'No Top250 found'); exit()
    for result in results:
        title = results[result]['title']
        year = results[result]['year']
        id = results[result]['id']
        poster = f"{_SERVER}/api/poster/{id}?do=show"
        addMovie(title, year, poster, id)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/Bottom100')
def bottom100():
    results = requests.get(f"{_SERVER}/api/bottom100movies/").json()["results"]
    if len(results) == 0: xbmcgui.Dialog().ok('Error', 'No Bottom100 found'); exit()
    for result in results:
        title = results[result]['title']
        year = results[result]['year']
        id = results[result]['id']
        poster = f"{_SERVER}/api/poster/{id}?do=show"
        addMovie(title, year, poster, id)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/play/<id>/<season>/<episode>')
def play(id, season, episode):
    isShow = True
    if season == "None" or episode == "None": isShow = False
    url = f"{_SERVER}/api/resolve/{id}"
    if isShow: url += f"?episode={season}-{episode}"
    resolved = requests.get(url).json()["url"]
    if resolved == "None": xbmcgui.Dialog().ok('Error', 'No video found'); exit()
    xbmcplugin.setResolvedUrl(plugin.handle, True, xbmcgui.ListItem(path=resolved))

if __name__ == "__main__": plugin.run(sys.argv)
